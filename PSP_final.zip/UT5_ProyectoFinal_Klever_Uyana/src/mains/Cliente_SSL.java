package mains;
import java.io.*;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class Cliente_SSL {
  public static void main(String[] args) throws IOException {
	  String Host = "localhost";
	int puerto = 5000;// puerto remoto
	
//---------------------- CAMBIOS PARA SSLsocket--------------------------
	
	//Socket Cliente = new Socket(Host, Puerto);
	
	//variables a a�adir.
	//primero se opriene las certificaciones creadas previamente
	String dir_cliente_certificado=".\\Certificados\\CliCertConfianza";
	//La clave es la que se intridujo al general los certificados
	String contrase�a="890123";
	
	System.out.println("Cliente Iniciado...");
	
	//Establece la propiedad del sistema indicada por la clave especificada	
	System.setProperty("javax.net.ssl.trustStore",dir_cliente_certificado);
    System.setProperty("javax.net.ssl.trustStorePassword", contrase�a);
    
    //creo un SSLSocketFactory llamada factory_ssl para mas tarde crear un SSLSocket
	SSLSocketFactory factory_ssl = (SSLSocketFactory) SSLSocketFactory.getDefault();
	SSLSocket cliente_ssl  = (SSLSocket) factory_ssl.createSocket(Host, puerto);
	
//------------------------------------------------------------------------	
//se crea un fuente de salida al servidor
	PrintWriter fsalida = new PrintWriter (cliente_ssl.getOutputStream(), true);
//fuente de entrada al servidor	
	BufferedReader fentrada =  new BufferedReader
	     (new InputStreamReader(cliente_ssl.getInputStream()));
//fuente estandar de entrada		 
	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	String cadena, eco="";
			
	do{ 
		System.out.print("Introduce cadena: ");
		cadena = in.readLine();
		fsalida.println(cadena);
		eco=fentrada.readLine();			
		System.out.println("  =>ECO: "+eco);	
	} while(!cadena.trim().equals("*")); 
	//do-while	
	fsalida.close();
	fentrada.close();
	System.out.println("Fin del env�o... ");
	in.close();
	cliente_ssl.close();
	}//Main
}//Cliente

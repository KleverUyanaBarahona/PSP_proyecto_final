package mains;

import java.io.*;	

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;

import co.isf.metodos_envio_hilo.HiloServidor;

public class Servidor_SSL {
	public static void main(String args[]) throws IOException  {
		//ServerSocket servidor;
		SSLSocket cliente_ssl = null;
		int puerto = 5000;
		String dir_servidor_certificado=".\\Certificados\\AlmacenSrv";
		String contrase�a_servidor="1234567";
		//servidor = new ServerSocket(5000);
//---------------------- CAMBIOS PARA SSLsocket--------------------------
		System.out.println("Servidor iniciado...");
		
		System.setProperty("javax.net.ssl.keyStore", dir_servidor_certificado);
        System.setProperty("javax.net.ssl.keyStorePassword", contrase�a_servidor);
        
        SSLServerSocketFactory factory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
		SSLServerSocket servidor_ssl = (SSLServerSocket) factory.createServerSocket(puerto);			
		
//---------------------- CAMBIOS PARA SSLsocket--------------------------		
		int i=0;
			
		while (true) {	
			i++;
			cliente_ssl = (SSLSocket) servidor_ssl.accept();
			HiloServidor hilo = new HiloServidor(cliente_ssl);
			hilo.run(i);
			
		}//while
	}//Main
}//Servidor


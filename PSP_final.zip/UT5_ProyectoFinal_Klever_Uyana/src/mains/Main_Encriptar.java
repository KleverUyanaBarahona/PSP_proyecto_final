package mains;

import java.io.File;
import java.util.Scanner;

import com.isf.rsa_encritar_desencriptar.Encriptar_archivo;

public class Main_Encriptar {

	public static void main(String[] args) {
		String dir_ficheros = ".\\Ficheros\\";
		String nombre_archivo;
		Scanner scanner = new Scanner(System.in);
		// TODO Auto-generated method stub
		System.out.println("*************************************");
		System.out.println("********** MAIN ENCRIPTAR ***********");
		System.out.println("*************************************\n");
		System.out.println("Lista de ficheros\n");

		File dir = new File(".\\Ficheros");
		String[] ficheros = dir.list();
		if (ficheros == null)
			  System.out.println("No hay ficheros en el directorio especificado");
			else { 
			  for (int x=0;x<ficheros.length;x++)
			    System.out.println(ficheros[x]);
			}
		System.out.print("\nIncloduce el nombre del archivo a Encriptar");
		nombre_archivo = scanner.next();
		
		File file = new File(dir_ficheros+nombre_archivo);
		
		Encriptar_archivo archivo = new Encriptar_archivo();
		archivo.encriptar_fichero(file);
		
		scanner.close();

	}

}

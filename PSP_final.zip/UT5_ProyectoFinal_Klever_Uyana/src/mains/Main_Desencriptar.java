package mains;

import java.io.File;
import java.util.Scanner;
import com.isf.rsa_encritar_desencriptar.Desencriptar_archivo;

public class Main_Desencriptar {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String dir_ficherosDes = ".\\FicherosEncriptados\\";
		String nombre_archivo;
		String clave_p = null;
		Scanner scanner = new Scanner(System.in);
		// TODO Auto-generated method stub
		System.out.println("*************************************");
		System.out.println("********* MAIN DESENCRIPTAR *********");
		System.out.println("*************************************\n");
		System.out.println("Lista de ficheros Encriptados\n");

		
		//Se pide el fichero encriptado
		File dir = new File(".\\FicherosEncriptados");
		String[] ficheros = dir.list();
		if (ficheros == null)
			  System.out.println("No hay ficheros en el directorio especificado");
			else { 
			  for (int x=0;x<ficheros.length;x++)
			    System.out.println(ficheros[x]);
			}
	
		System.out.print("\nIncloduce el nombre del archivo a Desencriptar");
		nombre_archivo = scanner.next();
		
		System.out.print("\n-----------------------------------------------\n");
		System.out.print("Lista de ficheros claves\n\n");
		
		//Se pide la clave
		try {
		File file2 = new File(".\\ClavesGeneradas");
		String[] ficheros2 = file2.list();
		if (ficheros2 == null)
			  System.out.println("No hay ficheros en el directorio especificado");
			else { 
			  for (int x=0;x<ficheros2.length;x++)
			    System.out.println(ficheros2[x]);
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		System.out.print("\nIncloduce el nombre del  fichero clave\n");
		clave_p = scanner.next();
		
		File file = new File(dir_ficherosDes+nombre_archivo);
		
		Desencriptar_archivo archivo2 = new Desencriptar_archivo();
		archivo2.desencriptar_fichero(file,clave_p);
		
		scanner.close();

	}
		
}


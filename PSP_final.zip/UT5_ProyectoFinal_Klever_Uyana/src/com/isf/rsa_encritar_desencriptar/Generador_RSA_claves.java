package com.isf.rsa_encritar_desencriptar;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.spec.RSAPublicKeySpec;

public class Generador_RSA_claves {
	
	private KeyPair pares_claves_rsa;
	String dir_claves=".\\ClavesGeneradas\\";
	static String nuevo_nombre;
	
	//Por si se quiere realizar en el hilo
	public static String GetDirectorioClave() {
		return nuevo_nombre;
	}
	
	//constructor de clase para claves RSA
	public Generador_RSA_claves() {
	try {
		//de generan par de claves
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		pares_claves_rsa = keyPairGenerator.generateKeyPair();
		System.out.println("Se han generado el par de claves");
	} catch (Exception e) {
		System.out.println("Error al generar las claves");
		e.printStackTrace();
		}
	}
	
		
	//M�todo get para saber las claves RSA tanto publica como privada.
	public KeyPair getClaves() {
		return pares_claves_rsa;
	}
	
	//Metodo para guardar le clave 
	public void guardar_clave_publica(String nombre_archivo) {
	try {
		nuevo_nombre=dir_claves+"clave_"+nombre_archivo;
		
		File file =new File(nuevo_nombre);
		if (file.exists()) {
				file.delete();
		}
		
		//factor�a de claves con cifrado RSA
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");

		//Creamos un Keyspec
		RSAPublicKeySpec publicKeySpec = keyFactory.getKeySpec(pares_claves_rsa.getPublic(),RSAPublicKeySpec.class);
		FileOutputStream stream = new FileOutputStream(nuevo_nombre);
		PrintWriter pw = new PrintWriter(stream);
		pw.println(publicKeySpec.getModulus());
		pw.println(publicKeySpec.getPublicExponent());
		pw.close();
		
		}catch (Exception e) {

		e.printStackTrace();
		}finally {
			System.out.println("Clave guardada");
		}
	}
	
}

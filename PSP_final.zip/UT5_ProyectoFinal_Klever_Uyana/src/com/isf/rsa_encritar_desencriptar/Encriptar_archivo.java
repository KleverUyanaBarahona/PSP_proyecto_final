package com.isf.rsa_encritar_desencriptar;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyPair;

import javax.crypto.Cipher;

public class Encriptar_archivo {
	String dir_encritados=".\\FicherosEncriptados\\";
	File archivo_encriptado;
	
	public File getArchivoEncriptado() {
		return archivo_encriptado;
	}
	
	public void encriptar_fichero(File archivo){
		try {
			//genero las claves
			Generador_RSA_claves generador_RSA_claves = new Generador_RSA_claves();
			KeyPair keyPair_claves = generador_RSA_claves.getClaves();
			//Se guarda clave en un archivo.
			generador_RSA_claves.guardar_clave_publica(archivo.getName());
			//Se encripta el archivo SE DEFINE EL OBJETO Cipher
			Cipher cipher = Cipher.getInstance("RSA");
			//se pone en modo encriptar
			cipher.init(Cipher.ENCRYPT_MODE,keyPair_claves.getPrivate());
			File file = archivo;
	
			archivo_encriptado = new File(dir_encritados+"Encrip_"+archivo.getName());
			
			if (archivo_encriptado.exists()) {
				archivo_encriptado.delete();
				System.out.println(archivo_encriptado+" existe pero a sido aliminado para el nuevo");
			}else {
				System.out.println("El fichero Encriptado no existe y sera creado");
				//System.exit(-1);
			}
			
			//Compruebo si existe  o no existe.
			if(archivo.exists()) {
				//fuente de entrada
				FileInputStream fileInputStream = new FileInputStream(file);
				//fuente de salida
				FileOutputStream fileOutputStream = new FileOutputStream(archivo_encriptado);
				
				byte[] bs_buffer = new byte[64];
				int bytes_leidos = fileInputStream.read(bs_buffer);
				while(bytes_leidos != -1) {
					byte[] c_buf = cipher.doFinal(bs_buffer, 0, bytes_leidos);
					fileOutputStream.write(c_buf);
					bytes_leidos = fileInputStream.read(bs_buffer);
				}
				fileInputStream.close();
				fileOutputStream.close();
			}else {
				System.out.println("El fichero a Encriptar no existe");
				//si no existe el programa termina.
				System.exit(0);
			}
			System.out.println("Se ha encriptado "+archivo.getName());
		}catch (Exception e) {
			System.out.println("Se ha producido un error al Encriptar ");
			e.printStackTrace();
		}finally {
			System.out.println("El programa a finalizado");
		}
	}
	
}

package com.isf.rsa_encritar_desencriptar;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.spec.RSAPublicKeySpec;

import javax.crypto.Cipher;

public class Desencriptar_archivo {
	
	String dir_desencrip=".\\FicherosDesencriptados\\";
	
	public void desencriptar_fichero(File archivo,String clave_p) {
		try {
			//ClavesGeneradas//clave_fichero1.txt
			String clave_publica = ".\\ClavesGeneradas\\"+clave_p;
			String dir_archivo = dir_desencrip+"Desencript_"+archivo.getName();
			
			//Recupero la clave publica
			BufferedReader bufferedReader = new BufferedReader(new FileReader(clave_publica));
			
			BigInteger bigInteger = new BigInteger(bufferedReader.readLine());
			BigInteger bigInteger2 = new BigInteger(bufferedReader.readLine());
			
			RSAPublicKeySpec rsaPublicKeySpec = new RSAPublicKeySpec(bigInteger, bigInteger2);
			
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			Key clave = keyFactory.generatePublic(rsaPublicKeySpec);
			//Se genera el cipher  y le damos la clave publica que estaba en el fichero encriptado
			//para despues desencrptarlo.
			
			Cipher cipher = Cipher.getInstance("RSA");
			//lo ponemos en modo desencriptar.
			cipher.init(Cipher.DECRYPT_MODE,clave);
			
			File file = archivo;
			
			File archivo_desencrip = new File(dir_archivo);
			
			if (archivo_desencrip.exists()) {
				archivo_desencrip.delete();
				System.out.println("El fichero Desencriptado existe y se borrora para dejar paso al nuevo");
			}else {
				System.out.println("El fichero Desencriptado no existe por lo tanto se creara");
				//System.exit(-1);
			}
			
			if(!file.exists()) {
				System.out.println("Fichero no existe...");
				System.exit(0);
			}else {
				FileInputStream fileInputStream = new FileInputStream(file);
				FileOutputStream fileOutputStream = new FileOutputStream(dir_archivo);
				//se a probado uno de 1000 , recomendado 256
				byte[] buffer = new byte[1000];
				
				int bytes = fileInputStream.read(buffer);
				while(bytes != -1) {
					fileOutputStream.write(cipher.doFinal(buffer,0, bytes));
					
					bytes = fileInputStream.read(buffer);
				}
				fileInputStream.close();
				fileOutputStream.close();
				bufferedReader.close();
			}
			
			System.out.println("Se a Desencriptado "+archivo.getName());
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error al Desencriptar");
			e.printStackTrace();
		}finally {
			System.out.println("Ha finalizado el programa");
		}
	}
}

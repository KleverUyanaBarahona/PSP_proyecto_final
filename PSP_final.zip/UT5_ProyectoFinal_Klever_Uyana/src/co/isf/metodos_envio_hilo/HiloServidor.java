package co.isf.metodos_envio_hilo;
import java.io.*;
import java.net.*;

public class HiloServidor extends Thread {
	BufferedReader fentrada;
	PrintWriter fsalida;
	Socket socket = null;
	int n;

	public HiloServidor(Socket s) throws IOException {// CONSTRUCTOR
		socket = s;
		// se crean flujos de entrada y salida
		fsalida = new PrintWriter(socket.getOutputStream(), true);
		fentrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));		
	}
	public void run(int n) {// tarea a realizar con el cliente
		
		String cadena = "";
		FileWriter f;
		try {		
			f = new FileWriter(new File(".\\Ficheros\\fichero" + n + ".txt"));
		BufferedWriter br = new BufferedWriter(f);
		
		File fich=new File(".\\Ficheros\\fichero" + n + ".txt");
		if (fich.exists()) {
			fich.delete();
		}
			
		System.out.println("COMUNICO CON: " + socket.toString());		
		int z=1;
				while (!cadena.trim().equals("*")) {
					try {
						cadena = fentrada.readLine();
						if(!cadena.equals("*")){
							if(z==0) 
							br.newLine();
							z=0;
							br.write(cadena);
							}							
					} catch (IOException e) {
						e.printStackTrace();
					} // obtener cadena
					fsalida.println("OK");// enviar may�scula
				} // fin while
				
				br.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}		
		System.out.println("FIN CON: " + socket.toString());

		fsalida.close();
		try {
			fentrada.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			EnvioFTP env;
			try {
				env = new EnvioFTP();
				env.SubirFichero(".\\Ficheros\\fichero"+n+".txt", "fichero"+n+".txt");
				//----------------------------------------------------------
				/*
				File file_encriptado = new File(".\\"+"fichero"+n+".txt");
				
				Encriptar_archivo archivo = new Encriptar_archivo();
				archivo.encriptar_fichero(file_encriptado);
				
				Desencriptar_archivo archivo2 = new Desencriptar_archivo();
				archivo2.desencriptar_fichero(archivo.getArchivoEncriptado());
				*/
				//----------------------------------------------------------
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			EnviarCorreo cor= new EnviarCorreo();
			cor.sendEmail(".\\Ficheros\\fichero"+n+".txt", socket.toString());
		}//try-cathc
	}//Run
	
}//Hilo Servidor
